import axios from 'axios';

export const handler = async (event, context) => {

	let data = JSON.stringify({
		"findItemsAdvancedRequest": {
			"itemFilter": [
				{
					"name": "ListingType",
					"value": "FixedPrice"
				},
				{
					"name": "Condition",
					"value": "1000"
				}
			],
			"paginationInput": {
				"entriesPerPage": 25,
				"pageNumber": 1
			}
		}
	});

	let config = {
		method: 'post',
		maxBodyLength: Infinity,
		url: `https://svcs.ebay.com/services/search/FindingService/v1?keywords=${event.queryStringParameters.search}`,
		headers: { 
			'X-EBAY-SOA-SECURITY-APPNAME': `${process.env.SecurityKey}`, 
			'X-EBAY-SOA-OPERATION-NAME': 'findItemsAdvanced', 
			'x-ebay-soa-response-data-format': 'JSON', 
			'x-ebay-soa-request-data-format': 'JSON', 
			'Content-Type': 'application/json'
		},
		data : data
	};

	try {
        const response = await axios.request(config);
		
		response.headers = {
			'Access-Control-Allow-Origin': '*',
		};

        return(JSON.stringify(response.data));
    } catch (error) {
        console.error(error);
    }

	return null;
};

